#ifndef GAME_H
#define GAME_H
#include "Player.h"
#include "Card.h"
class Game {
	
private:
	
	int playersNum,cardsNum;
public:
	
	Game();
	void start();
};
#endif




