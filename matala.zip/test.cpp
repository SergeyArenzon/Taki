#include "Card.h"

#include "iostream"
using namespace std;

int main(){
Card c;
//c.generate_card();
//cout<<c<<endl;


    return 0;
}